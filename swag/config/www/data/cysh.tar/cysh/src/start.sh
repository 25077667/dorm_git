#!/bin/bash
docker run -d --rm --expose=50000-60000 --name=golang101 zxc25077667/golang101
